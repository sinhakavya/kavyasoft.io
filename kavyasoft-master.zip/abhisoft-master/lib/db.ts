// lib/db.ts - Add connection validation
import { PrismaClient } from "@/generated/prisma"

const prisma = new PrismaClient({
  log: ['query', 'info', 'warn', 'error'],
  datasources: { db: { url: process.env.DATABASE_URL } }
})

// Verify connection on startup
prisma.$connect()
  .then(() => console.log('DB Connected'))
  .catch(err => console.error('Connection error', err))

export default prisma