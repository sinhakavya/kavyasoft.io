import React from 'react'
import YouTubeVideoDownloader from '@/components/youtube-video-downloader/YouTubeVideoDownloader.jsx'

export default function page() {
     return (
          <>
               <main className="min-h-[85vh] flex items-start justify-center pt-8 px-4 bg-gray-100 dark:bg-gray-900">
                    <YouTubeVideoDownloader />
               </main >
          </>
     )
}
