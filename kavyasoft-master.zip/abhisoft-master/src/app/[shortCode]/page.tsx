import { redirect } from "next/navigation";
import { notFound } from "next/navigation";
import prisma from "../../../lib/db";

export default async function RedirectPage({ params }: { params: Promise<{ shortCode: string }> }) {
  const { shortCode } = await params;

  const url = await prisma.url.findUnique({
    where: { shortUrl: shortCode }
  });

  if (!url) {
    notFound();
  } else {
    await prisma.url.update({
      where: {
        id: url.id,
      },
      data: { visit: { increment: 1 } }
    })
    redirect(url.originalUrl);
  }
}