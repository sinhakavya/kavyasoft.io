import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Nav from "@/components/home/nav/Nav";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AbhiSoft - Free Tools",
  description: "AbhiSoft brings together multiple daily-use tools.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Prevent dark mode flash on load */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
          (function () {
            const theme = localStorage.getItem("theme");
            const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
            if (theme === "dark" || (!theme && prefersDark)) {
              document.documentElement.classList.add("dark");
            }
          })();
        `,
          }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-white text-gray-800 dark:bg-gray-900 dark:text-white transition-colors`}
      >
        <div className="min-h-screen flex flex-col">
          <Nav />
          {children}
          <footer className="text-center text-xs sm:text-sm text-gray-500 dark:text-gray-400 py-4 border-t border-gray-200 dark:border-gray-700 select-none">
            &copy; {new Date().getFullYear()}{" "}
            <a href="/" className="underline">
              AbhiSoft.
            </a>{" "}
            Developed with ❤️ by{" "}
            <a
              href="https://abhijeet-kumar.vercel.app/"
              className="underline mx-1"
            >
              Abhijeet
            </a>
          </footer>
        </div>
      </body>
    </html>
  );
}

