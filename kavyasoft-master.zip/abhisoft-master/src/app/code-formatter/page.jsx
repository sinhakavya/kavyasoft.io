import CodeFormatter from "@/components/code-formatter/CodeFormatter";

export default function Page() {
     return (
          <main className="min-h-[85vh] flex items-start justify-center pt-8 px-4 bg-gray-100 dark:bg-gray-900">
               <CodeFormatter />
          </main>
     );
}
