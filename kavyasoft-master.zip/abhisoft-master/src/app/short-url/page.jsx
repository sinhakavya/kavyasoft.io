import UrlShortenerContainer from "@/components/url-shortener/url-shortener-container";

export const metadata = {
     title: "AbhiSoft - Free Link Shortener - Create Short URLs Instantly",
     description:
          "Shorten long URLs for free with our fast and easy link shortener. No signup required. Share branded and trackable short links instantly.",
};

export default function Page() {
     return (
          <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white transition-colors">
               <main className="flex-grow flex items-center justify-center py-8 px-4 sm:py-12">
                    <div className="url-card w-full max-w-md sm:max-w-4xl md:max-w-4xl bg-white dark:bg-gray-800 shadow-sm rounded-lg sm:rounded-2xl p-4 sm:p-4 space-y-4">
                         <div className="text-center space-y-3 sm:space-y-4">
                              <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold leading-tight">
                                   URL Shortener
                              </h1>
                              <p className="text-sm sm:text-base md:text-lg text-gray-600 dark:text-gray-300 max-w-xl mx-auto leading-relaxed">
                                   Shorten your URLs and share them easily!
                              </p>
                         </div>
                         <UrlShortenerContainer />
                    </div>
               </main>
          </div>
     );
}
