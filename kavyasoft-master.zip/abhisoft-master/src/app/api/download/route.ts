import { NextRequest } from "next/server";
import ytdl from "ytdl-core";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const url = searchParams.get("url");

  if (!url || !ytdl.validateURL(url)) {
    return new Response("Invalid YouTube URL", { status: 400 });
  }

  try {
    const info = await ytdl.getInfo(url);
    const title = info.videoDetails.title.replace(/[^a-zA-Z0-9 ]/g, "");
    const headers = new Headers({
      "Content-Disposition": `attachment; filename="${title}.mp4"`,
      "Content-Type": "video/mp4",
    });

    const readable = ytdl(url, {
      filter: "audioandvideo",
      quality: "highest",
    });

    return new Response(readable as any, { headers });
  } catch (err) {
    console.error(err);
    return new Response("Download failed", { status: 500 });
  }
}
