import { NextRequest, NextResponse } from "next/server";
import prisma from "../../../../../lib/db";

export async function DELETE(
  request: NextRequest,
  context: { params: Promise<{ code: string }> }
) {
  const { code } = await context.params;

  if (!code || typeof code !== "string") {
    return NextResponse.json({ error: "Invalid code" }, { status: 400 });
  }

  const url = await prisma.url.findUnique({ where: { shortUrl: code } });

  if (!url) {
    return NextResponse.json({ error: "URL not found" }, { status: 404 });
  }

  try {
    await prisma.url.delete({ where: { shortUrl: code } });

    return NextResponse.json({ message: "URL deleted successfully" });
  } catch (error) {
    console.error("Delete error:", error);
    return NextResponse.json({ error: "Failed to delete URL" }, { status: 500 });
  }
}
