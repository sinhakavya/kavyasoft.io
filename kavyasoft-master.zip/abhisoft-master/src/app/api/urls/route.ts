import { NextRequest, NextResponse } from "next/server";
import prisma from "../../../../lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const deviceId = searchParams.get("deviceId");

    if (!deviceId) {
      return NextResponse.json({ error: "Missing deviceId" }, { status: 400 });
    }

    const urls = await prisma.url.findMany({
      where: { deviceId },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(urls);
  } catch (error) {
    console.error("Error fetching", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
