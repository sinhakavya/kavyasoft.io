import { NextRequest, NextResponse } from "next/server";
import prisma from "../../../../lib/db";
import { nanoid } from "nanoid";
import { URL } from "url";
export async function POST(request: NextRequest) {
  try {
    const { url, deviceId } = await request.json(); // ✅ extract deviceId

    if (!url || typeof url !== "string") {
      return NextResponse.json({ error: "Invalid URL" }, { status: 400 });
    }

    try {
      new URL(url);
    } catch {
      return NextResponse.json({ error: "Invalid URL" }, { status: 400 });
    }

    let shortUrl = nanoid(8);
    let existingUrl = await prisma.url.findUnique({ where: { shortUrl } });

    while (existingUrl) {
      shortUrl = nanoid(8);
      existingUrl = await prisma.url.findUnique({ where: { shortUrl } });
    }

    const newEntry = await prisma.url.create({
      data: {
        originalUrl: url,
        shortUrl,
        deviceId, // ✅ store it
      },
    });

    return NextResponse.json({ shortUrl: newEntry.shortUrl });
  } catch (error) {
    console.error("API Error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
