const tools = [
  {
    title: "Link Shortener",
    description: "Shorten long URLs quickly and share them anywhere.",
    href: "/short-url",
    icon: "Link2",
    color: "indigo",
  },
  {
    title: "Text Formatter",
    description: "Clean, format, or beautify your text instantly.",
    href: "/text-formatter",
    icon: "Wand2",
    color: "orange",
  },
  {
    title: "Image Converter",
    description: "Convert images between JPG, PNG, WEBP, and more with ease.",
    href: "/image-converter",
    icon: "ImageIcon",
    color: "green"
  },
  {
    title: "Code Formatter",
    description: "Clean, format, or beautify your code instantly.",
    href: "/code-formatter",
    icon: "Code2",
    color: "yellow",
  },
  {
    title: "Image → PDF",
    description: "Convert your images into high-quality PDF files in one click.",
    href: "/image-to-pdf",
    icon: "FileImage",
    color: "red",
  },
  {
    title: "Word → PDF",
    description: "Convert .docx Word documents to PDF files easily.",
    href: "/word-to-pdf",
    icon: "FileText",
    color: "blue"
  },
  {
    title: "PDF → Word",
    description: "Convert PDF documents into editable Word files effortlessly.",
    href: "/pdf-to-word",
    icon: "FileText",
    color: "blue",
  },
  {
    title: "YouTube Downloader",
    description: "Download YouTube videos quickly and easily.",
    href: "/youtube-video-downloader",
    icon: "Youtube",
    color: "red"
  }




];

export default tools;


