"use client";
import React, { useState } from 'react';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import Swal from 'sweetalert2';
import { nanoid } from 'nanoid';

interface ShortenerFormProps {
     handleShortened: () => void;
}

const getDeviceId = (): string => {
     let id = localStorage.getItem('device_id');
     if (!id) {
          id = nanoid();
          localStorage.setItem('device_id', id);
     }
     return id;
};


export default function ShortenerForm({ handleShortened }: ShortenerFormProps) {

     const [url, setUrl] = useState<string>('');
     const [isLoading, setLoading] = useState<boolean>(false);

     const handleSubmit = async (e: React.FormEvent) => {
          e.preventDefault();

          if (!url.trim()) {
               Swal.fire({
                    title: 'Error!',
                    text: 'Please enter a URL to shorten.',
                    icon: 'error',
               });
               return;
          }

          setLoading(true);
          
          try {
               const deviceId = getDeviceId();
               const response = await fetch('/api/shorten', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ url, deviceId }),
               });

               const data = await response.json();

               if (!response.ok) {
                    throw new Error(data.error || 'Unknown error');
               }
               setUrl('');
               handleShortened();
          } catch (e) {
               if (e instanceof Error) {
                    Swal.fire({
                         title: 'Error!',
                         text: e.message,
                         icon: 'error',
                    });
               } else {
                    Swal.fire({
                         title: 'Error!',
                         text: 'An unknown error occurred.',
                         icon: 'error',
                    });
               }          
          } finally {
               setLoading(false);
          }
     };

     return (
          <form onSubmit={handleSubmit} className='mb-4'>
               <div className='space-y-4'>
                    <Input
                         className='h-12'
                         value={url}
                         onChange={(e) => setUrl(e.target.value)}
                         type='url'
                         placeholder='Enter URL to shorten'
                    />
                    <Button className='w-full p-2 cursor-pointer' type='submit' disabled={isLoading}>
                         {
                              isLoading ? 'Shortening...' : 'Shorten Url'
                         }
                    </Button>
               </div>
          </form>
     );

}
