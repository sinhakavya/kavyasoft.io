"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Button } from "../ui/button";
import { Check, CopyIcon, EyeIcon, Trash2 } from "lucide-react";
import Swal from 'sweetalert2';

type Url = {
  id: string;
  originalUrl: string;
  shortUrl: string;
  createdAt: string;
  visit: number;
};

export default function UrlList() {
  const [urls, setUrls] = useState<Url[]>([]);
  const [copied, setCopied] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const [deleting, setDeleting] = useState<string | null>(null);

  const shortenerUrl = (code: string) =>
    `${process.env.NEXT_PUBLIC_BASEURL || "http://localhost:3000"}/${code}`;

  const fetchUrls = async () => {
    setIsLoading(true);
    try {
      const deviceId = localStorage.getItem("device_id");
      const res = await fetch(`/api/urls?deviceId=${deviceId}`);
      if (!res.ok) throw new Error("Failed to fetch URLs");
      const data = await res.json();
      setUrls(data);
    } catch (error) {
      console.error("Error fetching URLs:", error);
    } finally {
      setIsLoading(false);
    }
  };


  const handleCopyUrl = (code: string) => {
    const fullUrl = shortenerUrl(code);
    navigator.clipboard.writeText(fullUrl).then(() => {
      setCopied(code);
      setTimeout(() => setCopied(null), 3000);
    });
  };

  const handleDeleteUrl = async (code: string) => {
    setDeleting(code);
    try {
      const res = await fetch(`/api/urls/${code}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        throw new Error("Failed to delete URL");
      }

      // Remove the deleted URL from the list
      setUrls((prev) => prev.filter((url) => url.shortUrl !== code));

      // Show Swal notification
      Swal.fire({
        title: 'URL Deleted!',
        text: 'The URL has been successfully deleted.',
        icon: 'success',
        timer: 2000,
        showConfirmButton: false,
      });
    } catch (error) {
      console.error("Error deleting URL:", error);
      // Display an error message to the user
      Swal.fire({
        title: 'Error!',
        text: 'Failed to delete URL.',
        icon: 'error',
      });
    } finally {
      setDeleting(null);
    }
  };
  useEffect(() => {
    fetchUrls();
  }, []);

  if (isLoading) {
    return (
      <div className="animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4 mb-4"></div>
        <ul className="space-y-2">
          {[...Array(5)].map((_, idx) => (
            <li
              key={idx}
              className="flex items-center gap-2 rounded-md border bg-card text-card-foreground justify-between p-3 bg-white dark:bg-gray-900"
            >
              <div className="h-4 bg-muted rounded w-1/2"></div>
              <div className="flex items-center gap-3">
                <div className="h-5 w-5 bg-muted rounded"></div>
                <span className="flex items-center gap-2">
                  <div className="h-4 w-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted w-10 rounded"></div>
                </span>
              </div>
            </li>
          ))}
        </ul>
      </div>
    );
  }

  if (!urls.length) {
    return (
      <div className="text-center text-red-500 mt-6">
        <h4 className="bg-white dark:bg-gray-900 rounded-md p-5"> No URLs found 😨</h4>
      </div>
    );
  }

  return (
    <div className="scroll-container">
      <h2 className="sticky-header bg-white dark:bg-gray-900">Recent URLs</h2>
      <ul className="space-y-2">
        {urls.map((url) => (
          <li
            key={url.id}
            className="flex items-center gap-2 justify-between bg-card rounded-md text-card-foreground border p-3 bg-white dark:bg-gray-900"
          >
            <Link
              href={shortenerUrl(url.shortUrl)}
              target="_blank"
              className="text-blue-500 underline truncate max-w-[60%]"
            >
              {shortenerUrl(url.shortUrl)}
            </Link>
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                className="text-muted-foreground hover:bg-muted cursor-pointer"
                onClick={() => handleCopyUrl(url.shortUrl)}
              >
                {copied === url.shortUrl ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <CopyIcon className="w-4 h-4" />
                )}
                <span className="sr-only">Copy URL</span>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="text-red-500 hover:bg-red-100 cursor-pointer"
                onClick={() => {
                  Swal.fire({
                    title: 'Are you sure?',
                    text: 'You won\'t be able to revert this!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                  }).then((result) => {
                    if (result.isConfirmed) {
                      handleDeleteUrl(url.shortUrl);
                    }
                  });
                }}
                disabled={deleting === url.shortUrl}
              >
                {deleting === url.shortUrl ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-red-500"></div>
                ) : (
                  <Trash2 className="w-4 h-4" />
                )}
              </Button>
              <span className="flex items-center gap-1 text-sm text-gray-600 bg-muted p-1 rounded-md">
                <EyeIcon className="h-4 w-4" /> {url.visit}
                <span className="hidden sm:flex ">views</span>

              </span>

            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
