"use client";

import React, { useRef, useState } from "react";
import { Download, FileImage, XCircle } from "lucide-react";
import jsPDF from "jspdf";

export default function ImageToPdfConverter() {
     const [previewUrl, setPreviewUrl] = useState(null);
     const fileInputRef = useRef(null);

     const handleImageUpload = (e) => {
          const file = e.target.files[0];
          if (file && file.type.startsWith("image/")) {
               const reader = new FileReader();
               reader.onload = () => setPreviewUrl(reader.result);
               reader.readAsDataURL(file);
          }
     };

     const handleRemoveImage = () => {
          setPreviewUrl(null);
          if (fileInputRef.current) fileInputRef.current.value = "";
     };

     const handleDownloadPdf = () => {
          if (!previewUrl) return;

          const img = new Image();
          img.src = previewUrl;

          img.onload = () => {
               const pdf = new jsPDF({
                    orientation: img.width > img.height ? "landscape" : "portrait",
                    unit: "px",
                    format: [img.width, img.height],
               });

               pdf.addImage(img, "PNG", 0, 0, img.width, img.height);
               pdf.save("converted.pdf");
          };
     };

     return (
          <div className="w-full max-w-2xl mx-auto p-6 bg-white dark:bg-gray-900 shadow-md rounded-xl space-y-6">
               <h2 className="text-2xl font-bold flex items-center gap-2 text-gray-800 dark:text-white">
                    <FileImage /> Image to PDF Converter
               </h2>

               <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="w-full p-2 border rounded-md dark:border-gray-700"
               />

               <div className="w-full h-64 flex justify-center items-center border rounded-lg bg-gray-50 dark:bg-gray-800 overflow-hidden relative">
                    {previewUrl ? (
                         <img
                              src={previewUrl}
                              alt="Preview"
                              className="max-h-full max-w-full object-contain"
                         />
                    ) : (
                         <p className="text-gray-400 dark:text-gray-500">No image uploaded</p>
                    )}
               </div>

               {previewUrl && (
                    <div className="flex justify-between items-center">
                         <button
                              onClick={handleRemoveImage}
                              className="text-red-500 hover:text-white border border-red-400 px-4 py-1 rounded-md hover:bg-red-500 transition flex items-center gap-2"
                         >
                              <XCircle className="w-4 h-4" /> Remove Image
                         </button>

                         <button
                              onClick={handleDownloadPdf}
                              className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition flex items-center gap-2"
                         >
                              <Download className="w-4 h-4" /> Download as PDF
                         </button>
                    </div>
               )}
          </div>
     );
}
