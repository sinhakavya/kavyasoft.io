"use client";

import React, { useRef, useState } from "react";
import { FileText, UploadCloud, Download, XCircle } from "lucide-react";
import mammoth from "mammoth";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

export default function WordToPdf() {
     const [htmlContent, setHtmlContent] = useState("");
     const [fileName, setFileName] = useState("");
     const fileInputRef = useRef(null);

     const handleUpload = async (e) => {
          const file = e.target.files[0];
          if (file && file.name.endsWith(".docx")) {
               setFileName(file.name.replace(".docx", ""));
               const arrayBuffer = await file.arrayBuffer();

               mammoth.convertToHtml({ arrayBuffer })
                    .then((result) => {
                         setHtmlContent(result.value);
                    })
                    .catch(() => alert("Failed to convert Word to HTML."));
          } else {
               alert("Please upload a valid .docx file.");
          }
     };

     const handleDownloadPDF = async () => {
          const content = document.getElementById("preview");
          if (!content) return;

          const canvas = await html2canvas(content, { scale: 2 });
          const imgData = canvas.toDataURL("image/png");
          const pdf = new jsPDF("p", "mm", "a4");
          const pdfWidth = pdf.internal.pageSize.getWidth();
          const imgProps = pdf.getImageProperties(imgData);
          const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

          pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
          pdf.save(`${fileName || "document"}.pdf`);
     };

     const handleRemove = () => {
          setHtmlContent("");
          setFileName("");
          if (fileInputRef.current) fileInputRef.current.value = "";
     };

     return (
          <div className="w-full max-w-3xl mx-auto p-6 bg-white dark:bg-gray-900 shadow-md rounded-xl space-y-6">
               <h2 className="text-2xl font-bold flex items-center gap-2 text-gray-800 dark:text-white">
                    <FileText /> Word to PDF Converter
               </h2>

               <input
                    ref={fileInputRef}
                    type="file"
                    accept=".docx"
                    onChange={handleUpload}
                    className="w-full p-2 border rounded-md dark:border-gray-700"
               />

               {htmlContent ? (
                    <>
                         <div
                              id="preview"
                              className="bg-white p-6 border border-gray-300 rounded-md shadow-inner dark:bg-gray-800 dark:border-gray-600 text-gray-900 dark:text-gray-100 max-h-[600px] overflow-y-auto leading-relaxed"
                              style={{ minHeight: "400px" }}
                              dangerouslySetInnerHTML={{ __html: htmlContent }}
                         />
                         <div className="flex justify-end gap-3">
                              <button
                                   onClick={handleRemove}
                                   className="flex items-center gap-2 px-4 py-2 border border-red-400 text-red-500 rounded-md hover:bg-red-100 dark:hover:bg-red-800 transition"
                              >
                                   <XCircle className="w-4 h-4" /> Remove
                              </button>
                              <button
                                   onClick={handleDownloadPDF}
                                   className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition"
                              >
                                   <Download className="w-4 h-4" /> Download PDF
                              </button>
                         </div>
                    </>
               ) : (
                    <p className="text-gray-500 dark:text-gray-400">Upload a `.docx` file to begin.</p>
               )}
          </div>
     );
}
