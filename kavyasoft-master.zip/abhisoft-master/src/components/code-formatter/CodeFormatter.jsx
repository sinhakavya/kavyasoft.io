"use client";

import React, { useState } from "react";
import prettier from "prettier/standalone";
import parserHtml from "prettier/parser-html";
import parserBabel from "prettier/parser-babel";
import parserPostcss from "prettier/parser-postcss";
import { Button } from "@/components/ui/button";
import { Code2, CopyIcon, Trash2 } from "lucide-react";

const languageParsers = {
     html: parserHtml,
     json: parserBabel,
     javascript: parserBabel,
     typescript: parserBabel,
     css: parserPostcss,
};

export default function CodeFormatter() {
     const [code, setCode] = useState("");
     const [language, setLanguage] = useState("html");

     const handleFormat = async () => {
          try {
               let formatted = code;

               if (language === "json") {
                    formatted = JSON.stringify(JSON.parse(code), null, 2);
               } else if (languageParsers[language]) {
                    formatted = await prettier.format(code, {
                         parser: language,
                         plugins: Object.values(languageParsers),
                    });
               } else {
                    alert("Formatting not supported for this language.");
                    return;
               }

               setCode(formatted);
          } catch (err) {
               alert("Invalid or unformatable code!");
               console.error(err);
          }
     };


     return (
          <div className="w-full max-w-5xl mx-auto p-6 space-y-4 bg-white dark:bg-gray-900 rounded-xl shadow-md">
               <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                    <h2 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
                         <Code2 className="h-6 w-6" /> Code Formatter
                    </h2>
                    <select
                         value={language}
                         onChange={(e) => setLanguage(e.target.value)}
                         className="border border-gray-300 dark:border-gray-700 rounded-md px-3 py-2 bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-gray-100"
                    >
                         <option value="html">HTML</option>
                         <option value="json">JSON</option>
                         <option value="javascript">JavaScript</option>
                         <option value="typescript">TypeScript</option>
                         <option value="css">CSS</option>
                         <option value="php">PHP (Not supported yet)</option>
                    </select>
               </div>

               <textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    rows={16}
                    placeholder="Paste your code here..."
                    className="w-full resize-none text-sm font-mono p-4 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-gray-100"
               />

               <div className="flex flex-wrap justify-between items-center gap-3">
                    <Button onClick={handleFormat}>Format</Button>
                    <Button
                         variant="ghost"
                         onClick={() => navigator.clipboard.writeText(code)}
                         className="flex items-center gap-2"
                    >
                         <CopyIcon className="h-4 w-4" /> Copy
                    </Button>
                    <Button
                         variant="destructive"
                         onClick={() => setCode("")}
                         className="flex items-center gap-2"
                    >
                         <Trash2 className="h-4 w-4" /> Clear
                    </Button>
               </div>
          </div>
     );
}
