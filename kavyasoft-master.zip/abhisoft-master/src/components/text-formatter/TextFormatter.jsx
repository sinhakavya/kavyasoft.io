"use client";

import React, { useState } from "react";
import {
     CopyIcon,
     Trash2,
     TextCursorInput,
     CaseLower,
     CaseUpper,
     AlignJustify,
     Type,
     Undo2,
     ListOrdered,
     Sparkles,
} from "lucide-react";

export default function TextFormatter() {
     const [inputText, setInputText] = useState("");

     const handleFormat = (action) => {
          let updated = inputText;

          switch (action) {
               case "trim":
                    updated = inputText.trim();
                    break;
               case "removeSpaces":
                    updated = inputText.replace(/\s+/g, " ").trim();
                    break;
               case "uppercase":
                    updated = inputText.toUpperCase();
                    break;
               case "lowercase":
                    updated = inputText.toLowerCase();
                    break;
               case "capitalize":
                    updated = inputText
                         .toLowerCase()
                         .replace(/\b\w/g, (char) => char.toUpperCase());
                    break;
               case "reverse":
                    updated = inputText.split("").reverse().join("");
                    break;
               case "removeLineBreaks":
                    updated = inputText.replace(/[\r\n]+/g, " ");
                    break;
               case "lineNumbers":
                    updated = inputText
                         .split("\n")
                         .map((line, idx) => `${idx + 1}. ${line}`)
                         .join("\n");
                    break;
               case "removeSpecialChars":
                    updated = inputText.replace(/[^\w\s]/gi, "");
                    break;
               case "slugify":
                    updated = inputText.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
                    break;
               case "clear":
                    updated = "";
                    break;
               default:
                    break;
          }

          setInputText(updated);
     };

     const handleCopy = () => {
          if (!inputText) {
               alert("Nothing to copy");
               return;
          }
          navigator.clipboard.writeText(inputText);
          alert("Copied to clipboard!");
     };

     return (
          <div className="w-full max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6 bg-white dark:bg-gray-900 rounded-xl shadow-md">
               <h2 className="text-2xl font-bold text-center text-gray-800 dark:text-white">
                    🛠️ Text Formatter
               </h2>

               <textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    rows={14}
                    placeholder="Paste or type your text here..."
                    className="w-full text-base resize-none p-4 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-gray-100"
               />

               <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                    <FormatButton label="Trim" icon={<TextCursorInput />} onClick={() => handleFormat("trim")} />
                    <FormatButton label="Clean" icon={<AlignJustify />} onClick={() => handleFormat("removeSpaces")} />
                    <FormatButton label="UPPER" icon={<CaseUpper />} onClick={() => handleFormat("uppercase")} />
                    <FormatButton label="lower" icon={<CaseLower />} onClick={() => handleFormat("lowercase")} />
                    <FormatButton label="Capitalize" icon={<Type />} onClick={() => handleFormat("capitalize")} />
                    <FormatButton label="Reverse" icon={<Undo2 />} onClick={() => handleFormat("reverse")} />
                    <FormatButton label="No Breaks" icon={<AlignJustify />} onClick={() => handleFormat("removeLineBreaks")} />
                    <FormatButton label="Line #" icon={<ListOrdered />} onClick={() => handleFormat("lineNumbers")} />
                    <FormatButton label="No Symbols" icon={<Trash2 />} onClick={() => handleFormat("removeSpecialChars")} />
                    <FormatButton label="Slugify" icon={<Sparkles />} onClick={() => handleFormat("slugify")} />
                    <FormatButton label="Copy" icon={<CopyIcon />} onClick={handleCopy} />
                    <FormatButton label="Clear" icon={<Trash2 />} onClick={() => handleFormat("clear")} isDestructive />
               </div>
          </div>
     );
}

function FormatButton({ label, icon, onClick, isDestructive = false }) {
     return (
          <button
               className={`flex items-center justify-center gap-1 px-3 py-2 rounded-md border text-sm transition-all
        ${isDestructive
                         ? "border-red-400 text-red-500 hover:bg-red-100 dark:hover:bg-red-800"
                         : "border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                    }
      `}
               onClick={onClick}
          >
               {icon} {label}
          </button>
     );
}
