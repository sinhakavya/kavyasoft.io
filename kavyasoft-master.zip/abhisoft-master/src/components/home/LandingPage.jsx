import Link from "next/link";
import * as Icons from "lucide-react";
import tools from "@/lib/tools";

const colorMap = {
     indigo: {
          bgLight: "bg-indigo-100",
          bgDark: "dark:bg-indigo-900",
          text: "text-indigo-600",
          link: "text-indigo-600 dark:text-indigo-400",
     },
     orange: {
          bgLight: "bg-orange-100",
          bgDark: "dark:bg-orange-900",
          text: "text-orange-600",
          link: "text-orange-600 dark:text-orange-400",
     },
     yellow: {
          bgLight: "bg-yellow-100",
          bgDark: "dark:bg-yellow-900",
          text: "text-yellow-600",
          link: "text-yellow-600 dark:text-yellow-400",
     },
     green: {
          bgLight: "bg-green-100",
          bgDark: "dark:bg-green-900",
          text: "text-green-600",
          link: "text-green-600 dark:text-green-400",
     },
     purple: {
          bgLight: "bg-purple-100",
          bgDark: "dark:bg-purple-900",
          text: "text-purple-600",
          link: "text-purple-600 dark:text-purple-400",
     },
     red: {
          bgLight: "bg-red-100",
          bgDark: "dark:bg-red-900",
          text: "text-red-600",
          link: "text-red-600 dark:text-red-400",
     },
};


export default function HomePage() {
     return (
          <>
               {/* Hero Section */}
               <section className="relative px-6 py-6 bg-gradient-to-br from-white to-gray-100 dark:from-gray-900 dark:to-gray-800 overflow-hidden">
                    <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 items-center gap-10">
                         <div className="text-center md:text-left">
                              <h2 className="text-4xl md:text-5xl font-bold leading-tight mb-4">
                                   <span className="text-orange-500">AbhiSoft</span> brings together multiple daily-use tools.
                              </h2>
                              <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-xl">
                                   Access all your essential tools — productivity, utility, and more — in one powerful platform. 100% free,
                                   blazing fast, and built to simplify your daily life.
                              </p>
                         </div>
                         <div className="relative flex justify-center md:justify-end">
                              <img src="/assets/hero.png" alt="Hero Illustration" className="w-full max-w-lg md:max-w-lg" />
                         </div>
                    </div>
               </section>

               {/* Tools Grid Section */}
               <section className="py-10 px-6 text-center bg-gradient-to-b from-gray-100 dark:from-gray-800 to-white dark:to-gray-900">
                    <h3 className="text-3xl font-bold mb-4">
                         Our <span className="text-orange-600">100%</span> Free <span className="text-indigo-600">Tools</span>
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 max-w-lg mx-auto mb-10">Try them today ☺️</p>

                    <div className="grid gap-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
                         {tools.map((tool, index) => {
                              const Icon = Icons[tool.icon];
                              const color = colorMap[tool.color] || colorMap.indigo;

                              return (
                                   <div
                                        key={index}
                                        className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-lg hover:shadow-xl hover:-translate-y-1 transition-transform duration-300"
                                   >
                                        <div
                                             className={`flex items-center justify-center w-12 h-12 mb-4 ${color.bgLight} ${color.bgDark} ${color.text} rounded-full mx-auto`}
                                        >
                                             {Icon && <Icon size={20} />}
                                        </div>
                                        <h4 className="font-semibold text-lg mb-2">{tool.title}</h4>
                                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{tool.description}</p>
                                        <Link href={tool.href} className={`inline-block ${color.link} font-medium hover:underline`}>
                                             Try Now →
                                        </Link>
                                   </div>
                              );
                         })}
                    </div>
               </section>
          </>
     );
}
