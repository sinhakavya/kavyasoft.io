"use client";

import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import Link from "next/link";

export default function Nav() {
     const [darkMode, setDarkMode] = useState(false);
     const [menuOpen, setMenuOpen] = useState(false);

     // Initialize theme from localStorage
     useEffect(() => {
          const storedTheme = localStorage.getItem("theme");
          const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
          const isDark = storedTheme === "dark" || (!storedTheme && prefersDark);

          setDarkMode(isDark);
          document.documentElement.classList.toggle("dark", isDark);
     }, []);

     // Toggle theme and store in localStorage
     useEffect(() => {
          if (darkMode) {
               document.documentElement.classList.add("dark");
               localStorage.setItem("theme", "dark");
          } else {
               document.documentElement.classList.remove("dark");
               localStorage.setItem("theme", "light");
          }
     }, [darkMode]);

     return (
          <header className="sticky top-0 bg-white dark:bg-gray-900 px-6 md:px-60 py-5 shadow-md dark:shadow-lg z-50">
               <div className="flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-orange-500">
                         <Link href={"/"}>Abhi<span className="text-indigo-500">Soft</span>.</Link>
                    </h1>
                    {/* Mobile menu toggle */}
                    <button
                         className="md:hidden text-gray-700 dark:text-white"
                         onClick={() => setMenuOpen(!menuOpen)}
                    >
                         {menuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>

                    {/* Desktop menu */}
                    <nav className="hidden md:flex space-x-8 text-sm font-medium items-center">
                         <Link href="/" className="hover:text-indigo-600 cursor-pointer">Home</Link>
                         <a
                              href="https://abhijeet-kumar.vercel.app/contact"
                              className="hover:text-indigo-600 cursor-pointer"
                              target="_blank" rel="noopener noreferrer"
                         >
                              Contact Developer
                         </a>
                         <button
                              onClick={() => setDarkMode(!darkMode)}
                              className="text-sm text-gray-700 dark:text-white cursor-pointer"
                         >
                              {darkMode ? "🌞 Light" : "🌙 Dark"}
                         </button>
                    </nav>
               </div>

               {/* Mobile menu dropdown */}
               {menuOpen && (
                    <div className="md:hidden mt-4 space-y-3 text-sm font-medium bg-white dark:bg-gray-900 p-4 rounded-lg shadow-md">
                         <Link href="/" className="block hover:text-indigo-600 cursor-pointer">Home</Link>
                         <a
                              href="https://abhijeet-kumar.vercel.app/contact"
                              className="block hover:text-indigo-600 cursor-pointer"
                              target="_blank" rel="noopener noreferrer"
                         >
                              Contact Developer
                         </a>
                         <button
                              onClick={() => setDarkMode(!darkMode)}
                              className="block text-left text-gray-700 dark:text-white cursor-pointer"
                         >
                              {darkMode ? "🌞 Light Mode" : "🌙 Dark Mode"}
                         </button>
                    </div>
               )}
          </header>
     );
}
