"use client";

import React, { useRef, useState } from "react";
import { FileText, Download, Trash2 } from "lucide-react";
import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf";
import { Document, Packer, Paragraph } from "docx";

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

export default function PdfToWord() {
     const [pdfFile, setPdfFile] = useState(null);
     const [docBlob, setDocBlob] = useState(null);
     const fileInputRef = useRef(null);

     const handlePdfUpload = async (e) => {
          const file = e.target.files?.[0];
          if (!file) return;

          setPdfFile(file);

          const fileReader = new FileReader();
          fileReader.onload = async () => {
               const typedArray = new Uint8Array(fileReader.result);
               const pdf = await pdfjsLib.getDocument({ data: typedArray }).promise;

               const paragraphs = [];

               for (let i = 1; i <= pdf.numPages; i++) {
                    const page = await pdf.getPage(i);
                    const textContent = await page.getTextContent();

                    const strings = textContent.items.map((item) => item.str).join(" ");
                    paragraphs.push(new Paragraph(strings));
               }

               const doc = new Document({
                    sections: [{ children: paragraphs }],
               });

               const blob = await Packer.toBlob(doc);
               setDocBlob(blob);
          };

          fileReader.readAsArrayBuffer(file);
     };

     const handleDownload = () => {
          if (!docBlob || !pdfFile) return;
          const link = document.createElement("a");
          link.href = URL.createObjectURL(docBlob);
          link.download = pdfFile.name.replace(/\.pdf$/i, "") + ".docx";
          link.click();
     };

     const handleRemove = () => {
          setPdfFile(null);
          setDocBlob(null);
          if (fileInputRef.current) fileInputRef.current.value = "";
     };

     return (
          <div className="max-w-2xl mx-auto p-6 bg-white dark:bg-gray-900 shadow-md rounded-xl space-y-6">
               <h2 className="text-2xl font-bold flex items-center gap-2 text-gray-800 dark:text-white">
                    <FileText /> PDF to Word Converter
               </h2>

               <input
                    type="file"
                    accept=".pdf"
                    ref={fileInputRef}
                    onChange={handlePdfUpload}
                    className="w-full p-2 border rounded-md dark:border-gray-700"
               />

               {pdfFile && (
                    <div className="text-gray-700 dark:text-gray-300 text-sm">
                         <strong>Uploaded:</strong> {pdfFile.name}
                    </div>
               )}

               <div className="flex flex-wrap gap-3 justify-end">
                    <button
                         onClick={handleRemove}
                         disabled={!pdfFile}
                         className="flex items-center gap-2 border border-red-500 text-red-500 px-4 py-2 rounded-md hover:bg-red-500 hover:text-white transition disabled:opacity-50"
                    >
                         <Trash2 className="w-4 h-4" />
                         Remove
                    </button>
                    <button
                         onClick={handleDownload}
                         disabled={!docBlob}
                         className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition disabled:opacity-50"
                    >
                         <Download className="w-4 h-4" />
                         Download Word File
                    </button>
               </div>
          </div>
     );
}
