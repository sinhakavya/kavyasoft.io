"use client";

import React, { useState } from "react";
import { Download, Youtube } from "lucide-react";

export default function YouTubeVideoDownloader() {
     const [videoUrl, setVideoUrl] = useState("");
     const [loading, setLoading] = useState(false);
     const [error, setError] = useState("");

     const handleDownload = async () => {
          setError("");
          if (!videoUrl.includes("youtube.com") && !videoUrl.includes("youtu.be")) {
               setError("Please enter a valid YouTube URL.");
               return;
          }

          try {
               setLoading(true);
               // This assumes your server has an endpoint: /api/download?url=...
               window.open(`/api/download?url=${encodeURIComponent(videoUrl)}`, "_blank");
          } catch (err) {
               setError("Something went wrong. Try again.");
               console.error(err);
          } finally {
               setLoading(false);
          }
     };

     return (
          <div className="w-full max-w-2xl mx-auto p-6 bg-white dark:bg-gray-900 shadow-md rounded-xl space-y-6">
               <h2 className="text-2xl font-bold flex items-center gap-2 text-gray-800 dark:text-white">
                    <Youtube className="text-red-600" /> YouTube Video Downloader
               </h2>

               <input
                    type="text"
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    placeholder="Enter YouTube video URL..."
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-md bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-gray-100"
               />

               {error && <p className="text-red-500 text-sm">{error}</p>}

               <div className="flex justify-end">
                    <button
                         onClick={handleDownload}
                         disabled={loading || !videoUrl}
                         className={`px-4 py-2 rounded-md flex items-center gap-2 transition ${loading || !videoUrl
                              ? "bg-gray-400 text-white cursor-not-allowed"
                              : "bg-red-600 text-white hover:bg-red-700"
                              }`}
                    >
                         <Download className="w-4 h-4" /> {loading ? "Processing..." : "Download"}
                    </button>
               </div>
          </div>
     );
}
