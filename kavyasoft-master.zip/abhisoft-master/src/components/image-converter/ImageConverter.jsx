"use client";

import React, { useRef, useState } from "react";
import { Download, ImageIcon, XCircle } from "lucide-react";

const formats = ["png", "jpeg", "webp", "bmp"];

export default function ImageConverter() {
     const [imageFile, setImageFile] = useState(null);
     const [outputFormat, setOutputFormat] = useState("png");
     const [previewUrl, setPreviewUrl] = useState(null);
     const fileInputRef = useRef(null);

     const handleImageUpload = (e) => {
          const file = e.target.files[0];
          if (file && file.type.startsWith("image/")) {
               setImageFile(file);
               const reader = new FileReader();
               reader.onload = () => setPreviewUrl(reader.result);
               reader.readAsDataURL(file);
          }
     };

     const handleRemoveImage = () => {
          setImageFile(null);
          setPreviewUrl(null);
          if (fileInputRef.current) {
               fileInputRef.current.value = "";
          }
     };

     const handleDownload = () => {
          if (!previewUrl || !imageFile) return;

          const img = new Image();
          img.src = previewUrl;

          img.onload = () => {
               const canvas = document.createElement("canvas");
               canvas.width = img.width;
               canvas.height = img.height;
               const ctx = canvas.getContext("2d");
               ctx.drawImage(img, 0, 0);

               canvas.toBlob(
                    (blob) => {
                         const link = document.createElement("a");
                         link.href = URL.createObjectURL(blob);
                         link.download = `converted-image.${outputFormat}`;
                         link.click();
                    },
                    `image/${outputFormat}`,
                    1.0
               );
          };
     };

     return (
          <div className="w-full max-w-2xl mx-auto p-6 bg-white dark:bg-gray-900 shadow-md rounded-xl space-y-6">
               <h2 className="text-2xl font-bold flex items-center gap-2 text-gray-800 dark:text-white">
                    <ImageIcon /> Image Converter
               </h2>

               <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="w-full p-2 border rounded-md dark:border-gray-700 cursor-pointer"
               />

               {/* Fixed preview area */}
               <div className="w-full h-64 flex justify-center items-center border rounded-lg bg-gray-50 dark:bg-gray-800 overflow-hidden relative">
                    {previewUrl ? (
                         <img
                              src={previewUrl}
                              alt="Preview"
                              className="max-h-full max-w-full object-contain"
                         />
                    ) : (
                         <p className="text-gray-400 dark:text-gray-500">No image uploaded</p>
                    )}
               </div>

               {/* Remove image button */}
               {previewUrl && (
                    <div className="flex justify-center">
                         <button
                              onClick={handleRemoveImage}
                              className="text-red-500 hover:text-white border border-red-400 px-4 py-1 rounded-md hover:bg-red-500 transition cursor-pointer flex items-center gap-2"
                         >
                              <XCircle className="w-4 h-4" /> Remove Image
                         </button>
                    </div>
               )}

               {/* Format + Download row */}
               <div>
                    <label className="text-gray-700 dark:text-gray-300 font-medium mb-2 block">
                         Convert to:
                    </label>
                    <div className="flex flex-wrap items-center justify-between gap-3">
                         <div className="flex flex-wrap gap-3">
                              {formats.map((format) => (
                                   <button
                                        key={format}
                                        onClick={() => setOutputFormat(format)}
                                        className={`px-4 py-2 rounded-md border cursor-pointer ${outputFormat === format
                                             ? "bg-indigo-600 text-white"
                                             : "bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-100"
                                             } hover:bg-indigo-500 hover:text-white transition`}
                                   >
                                        {format.toUpperCase()}
                                   </button>
                              ))}
                         </div>

                         <button
                              onClick={handleDownload}
                              disabled={!previewUrl}
                              className={`px-4 py-2 rounded-md transition flex items-center cursor-pointer gap-2 ${previewUrl
                                   ? "bg-indigo-600 text-white hover:bg-indigo-700"
                                   : "bg-gray-400 text-white cursor-not-allowed"
                                   }`}
                         >
                              <Download className="w-4 h-4" /> Download Image
                         </button>
                    </div>
               </div>
          </div>
     );
}
